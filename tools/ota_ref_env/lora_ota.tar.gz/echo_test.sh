#!/bin/sh
touch /.ota_test
