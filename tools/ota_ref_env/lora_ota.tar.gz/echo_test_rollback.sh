#!/bin/sh
rm -f /.ota_test
