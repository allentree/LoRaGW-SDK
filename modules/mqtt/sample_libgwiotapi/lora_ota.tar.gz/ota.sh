#!/bin/sh 

echo "Begin upgrade file"

echo "cp test"
cp /tmp/lora_ota/test /opt/lora-net/gateway/packet_forwarder/gps_pkt_fwd/test
chmod 755 /opt/lora-net/gateway/packet_forwarder/gps_pkt_fwd/test

killall mqtt
echo "cp mqtt"
cp /tmp/lora_ota/mqtt /opt/lora-net/gateway/packet_forwarder/gps_pkt_fwd/mqtt
chmod 755 /opt/lora-net/gateway/packet_forwarder/gps_pkt_fwd/mqtt

echo "update sys ver"
sed -i -r 's/ota.ver:.*/ota.ver:2.0.8/g' /opt/lora-net/gateway/packet_forwarder/gps_pkt_fwd/sysconfig.db

echo "End upgrade file"

sleep 5

reboot
